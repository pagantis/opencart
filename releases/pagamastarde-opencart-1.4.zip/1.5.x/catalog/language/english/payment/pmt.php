<?php
// Text
$_['text_title'] = 'Paga+Tarde <div style="width:185px;top:-20px;" class="pmt-custom pmt-detail pmt-simulator" data-pmt-num-quota="4" data-pmt-style="neutral" data-pmt-type="3" data-pmt-discount="%d" data-pmt-amount="%f" data-pmt-expanded="no"></div>
  <script type ="text/javascript" src ="https://cdn.pagamastarde.com/pmt-simulator/2/js/pmt-simulator.min.js">
  </script>';
$_['text_testmode'] = 'PAYMENT GATEWAY IS IN TEST MODE - NO CHARGE WILL BE MADE';
$_['terms'] = '';
$_['heading_fail'] = 'Transaction Failed!';
$_['message_fail'] = '<p>There was a problem with your payment details.</p><p><strong>Your card has not been charged</strong></p><p>Please click continue to try again</p>';
