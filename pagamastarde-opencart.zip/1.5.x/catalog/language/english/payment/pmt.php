<?php
// Text
$_['text_title'] = 'Paga Mas Tarde';
$_['text_testmode'] = 'PAYMENT GATEWAY IS IN TEST MODE - NO CHARGE WILL BE MADE';
$_['terms'] = '';
$_['heading_fail'] = 'Transaction Failed!';
$_['message_fail'] = '<p>There was a problem with your payment details.</p><p><strong>Your card has not been charged</strong></p><p>Please click continue to try again</p>';
